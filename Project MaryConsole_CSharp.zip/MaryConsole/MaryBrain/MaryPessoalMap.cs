﻿using MongoDB.Bson.Serialization;


namespace MaryBrain
{
    public class MaryPessoalMap
    {
        public static void Configure()
        {
            BsonClassMap.RegisterClassMap<MaryPessoal>(map =>
            {
                map.AutoMap();
                map.SetIgnoreExtraElements(true);
                map.MapIdMember(x => x.Id);
                map.MapMember(x => x.Documento).SetIsRequired(true);
                map.MapMember(x => x.Name).SetIsRequired(true);
                map.MapMember(x => x.Funcao).SetIsRequired(true);
            });
        }
    }
}
