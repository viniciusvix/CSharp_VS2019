﻿using System;
using System.Collections.Generic;
using System.Text;
using MongoDB.Driver;

namespace MaryBrain
{
    public class ConexaoMongoDB
    {
        private static IMongoClient mongoClient;
        private static IMongoDatabase mongoDatabase;
        private static string _STRINGCONNECTION = @"mongodb://localhost:27017";
        private static string _DATA_BASE_NAME = "marydb";

        public static void Conectar(string nomeBanco)
        {
            mongoClient = new MongoClient(_STRINGCONNECTION);
            if(nomeBanco == string.Empty)
                mongoDatabase = mongoClient.GetDatabase(_DATA_BASE_NAME);
            else
                mongoDatabase = mongoClient.GetDatabase(nomeBanco);
        }

        public static IMongoDatabase DataBase
        {
            get { return mongoDatabase; }
        }

    }
}
