﻿using System;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;

namespace MaryBrain
{
    [BsonIgnoreExtraElements]
    public class MaryPessoal
    {
        [BsonId, BsonRepresentation(BsonType.ObjectId)]
        public String Id { get; protected set; }
        
        [BsonRequired]
        public String Documento { get; }

        public String Name { get; }

        public String Funcao { get; }

    }
}
