﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using MongoDB.Bson;
using MongoDB.Driver;

namespace MaryBrain
{
    public class MaryPessoalCollection
    {
        private static IMongoDatabase mongoDatabase;

        public static MaryPessoal GetMaryApresentacao
        {
            get {
                IMongoCollection<MaryPessoal> colMary = mongoDatabase.GetCollection<MaryPessoal>("maryApresentacao");
                Expression<Func<MaryPessoal, bool>> filter = x => x.Documento.Equals("APRESENTACAO_0");

                MaryPessoal maryPessoal = colMary.Find(filter).FirstOrDefault();

                return maryPessoal;
            }
        }

        /*public static string GetFalaMary(string fala)
        {
            IMongoCollection<dynamic> collection = mongoDatabase.GetCollection<dynamic>("maryApresentacao");
            Expression<Func<dynamic, bool>> filter =  x => x.Documento.Equals("APRESENTACAO_1");
            MaryFalas objMaryFalas = collection.Find(filter);
        }*/
    }
}
