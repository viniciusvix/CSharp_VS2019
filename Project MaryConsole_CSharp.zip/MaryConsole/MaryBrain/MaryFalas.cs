﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace MaryBrain
{
    [BsonIgnoreExtraElements]
    public class MaryFalas
    {
        [BsonId, BsonRepresentation(BsonType.ObjectId)]
        public String Id { get; protected set; }

        [BsonRequired]
        public String Documento { get; }

        public String ola { get; }
        public String apresentacao { get; }
        public String oferecerAjuda { get; }
        public String falaManha { get; }
        public String fataTarde { get; }
        public String falaNoite { get; }
        public String agradecimento { get; }
        public String senhor { get; }
        public String senhora { get; }
        public String garoto { get; }
        public String identificacao { get; }

    }
}
