﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech.Synthesis;


namespace MaryConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            SpeechSynthesizer falar = new SpeechSynthesizer();
            falar.SetOutputToDefaultAudioDevice();
            falar.Rate = -3;
            falar.Volume = 100;

            MaryBrain.ConexaoMongoDB.Conectar("jarvisdados");
            //MaryPessoal mary = maryDB.


            falar.Speak("Hellow Vini.");
            falar.Speak("How can i help you ?");
        }
    }
}
