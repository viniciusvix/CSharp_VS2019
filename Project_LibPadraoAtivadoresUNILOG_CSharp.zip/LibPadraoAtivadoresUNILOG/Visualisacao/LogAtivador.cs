﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using LibPadraoAtivadoresUNILOG.Conectividade;
//using Oracle.ManagedDataAccess.Client;
using Oracle.DataAccess.Client;


namespace LibPadraoAtivadoresUNILOG
{
    public class LogAtivador
    {
        private string strPath;
        private string strArquivoLog;
        private long idExecucao;
        private bool blGravarembanco = false;
        private string transacao;
        private BDConexaoBancoDados BDLog;

        public LogAtivador(string path, string fileName, long id, string strTransacao = "", bool logBanco = false)
        {
            strPath = path;
            strArquivoLog = fileName + "_" + DateTime.Now.ToString("yyyy_MM_dd") + ".log";
            idExecucao = id;
            transacao = strTransacao;
            blGravarembanco = logBanco;
        }

        public void RegistrarLog(string descricao)
        {
            string log = @"Log: {" +
                          "transacao:" + transacao + "," +
                          "ID:" + idExecucao + "," +
                          "datahora:" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss:fff") + ","+
                          "text:" + descricao +
                          "}";

            using (StreamWriter w = File.AppendText(strPath + "\\" + strArquivoLog))
            {
                w.WriteLine("\r\nLog: {");
                w.WriteLine("'ID':" + idExecucao + ",");
                w.WriteLine("'Transacao':" + transacao + ",");
                w.WriteLine("'datahora':" + "'" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss:fff") + "',");
                w.WriteLine("'text':" + "'" + descricao + "'");
                w.WriteLine("\r}");
            }

            //Registrando Log na base de dados
            if (blGravarembanco)
            {
                try
                {
                    BDLog = new BDConexaoBancoDados();
                    string sqlInsert = @"INSERT INTO LOG_ERRO (TEXTO, TIMESTAMP) VALUES ('" + log + "', SYSDATE)";

                    BDLog.ExecuteQuery<OracleConnection>(sqlInsert);
                }
                catch (Exception oErro)
                { }
            }
        }
    }
}
