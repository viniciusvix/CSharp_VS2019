﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LibPadraoAtivadoresUNILOG.Conectividade;
//using Oracle.ManagedDataAccess.Client;
using Oracle.DataAccess.Client;
using System.Data;

namespace LibPadraoAtivadoresUNILOG.Visualisacao
{
    public class ParamsProcedure
    {
        public string name;
        public string tipo;
        public string valorString;
        public DateTime valorDateTime;
        public decimal valorDecimal;
        public long valorNumerico;
    }


    public class ExecucaoAtivador
    {
        public static string nomeTransacao;
        public static string nomeAtivador;
        public static long idExecucao;
        public static LogAtivador log;
        public static List<String> Params;
        private static BDConexaoBancoDados BDLog;

        public static void IniciarAtivador(string path, string filename, string pTransacao, string pNomeAtivador, bool logBanco = false)
        {
            idExecucao = Convert.ToInt64(DateTime.Now.ToString("ddMMyyyyhhmmss"));
            nomeTransacao = pTransacao;
            nomeAtivador = pNomeAtivador;
            log = new LogAtivador(path, filename, idExecucao, pTransacao, logBanco);
            BDLog = new BDConexaoBancoDados();
            Params = new List<string>();
    }

        public virtual string ExecutarComponente()
        {
            string strResposta = string.Empty;
            return strResposta;
        }

        public static string BuscarParametroTransacao(string transacao, string parametro1, string parametro2)
        {
            string retorno = "";
            try
            {
                log.RegistrarLog("buscando parâmetro...");
                string sql = @"select ptr.PTR_TXT_CE2 from transacao ts, parametro_transacao ptr " +
                             "   where ts.TS_IDT_TRS = ptr.TS_IDT_TRS " +
                             "     and ts.TS_COD_TRS = '" + transacao + "' " +
                             "     and ptr.PTR_COD_PTR = '" + parametro1 + "' " +
                             "     and ptr.PTR_TXT_CE1 = '"+ parametro2 + "'";
                DataTable dt = BDLog.LeDados<OracleConnection>(sql);

                if(dt.Rows.Count > 0)
                    retorno = dt.Rows[0]["PTR_TXT_CE2"].ToString();

            }
            catch (Exception oErro)
            {
                log.RegistrarLog("ERRO: " + oErro.Message);
                retorno = "1;" + oErro.Message;
            }

            return retorno;
        }

        public static string ExecutarProcedure(string procedureName, List<ParamsProcedure> parametros)
        {
            string retorno = "0;;";
            try
            {
                log.RegistrarLog("Lendo lista de parâmetros...");
                List<OracleParameter> lstParams = new List<OracleParameter>();
                foreach (ParamsProcedure val in parametros)
                {
                    OracleParameter prm = new OracleParameter();
                    prm.ParameterName = val.name;
                    if (val.tipo == "STRING")
                    {
                        prm.OracleDbType = OracleDbType.Varchar2;
                        prm.Value = val.valorString;
                    }else if(val.tipo == "DATE")
                    {
                        prm.OracleDbType = OracleDbType.Date;
                        prm.Value = val.valorDateTime;
                    }
                    else if (val.tipo == "NUMERIC")
                    {
                        prm.OracleDbType = OracleDbType.Long;
                        prm.Value = val.valorNumerico;
                    }
                    else if (val.tipo == "DECIMAL")
                    {
                        prm.OracleDbType = OracleDbType.Decimal;
                        prm.Value = val.valorDecimal;
                    }

                    lstParams.Add(prm);
                }

                BDLog = new BDConexaoBancoDados();
                log.RegistrarLog("Executando Procedure Oracle: " + procedureName);
                BDLog.ExecuteProcedureOracle<OracleConnection>(procedureName, lstParams);
                log.RegistrarLog("Fim Execução Procedure.");

            }
            catch (Exception oErro)
            {
                log.RegistrarLog("ERRO: " + oErro.Message);
                retorno = "1;" + oErro.Message;
            }

            return retorno;
        }
    }
}
