﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
//using Oracle.ManagedDataAccess.Client;
using Oracle.DataAccess.Client;

namespace LibPadraoAtivadoresUNILOG.Conectividade
{
    public class BDConexaoBancoDados
    {
        private string connectionString;
        public string ConnectionString
        {
            get
            {
                //DESENVOLVIMENTO
                //string conn = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=10.1.114.201)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=dvlie)));User Id=TRANSLOGIC;Password=adq4913q;";
                //HOMOLOGACAO
                //string conn = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=10.1.114.152)(PORT=1521))(ADDRESS=(PROTOCOL=tcp)(HOST=10.1.114.164)(PORT=1521))(LOAD_BALANCE = yes)(CONNECT_DATA=(SERVER = DEDICATED)(SERVICE_NAME=hvlie)));User Id=TRANSLOGIC;Password=adq4913q;";
                //PRODUCAO
                //string conn = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=ora-pvlie-01.vlinet.local)(PORT=1521))(ADDRESS=(PROTOCOL=tcp)(HOST=ora-pvlie-02.vlinet.local)(PORT=1521))(LOAD_BALANCE = yes)(CONNECT_DATA=(SERVER = DEDICATED)(SERVICE_NAME=pvlie)));User Id=TRANSLOGIC;Password=adq4913q;";

                //string conn = "Password=adq4913q;User ID=translogic;Data Source=engesis-s1;";
                string conn = "Password=adq4913q;User ID=translogic;Data Source=engesis-s1;Persist Security Info=True";

                return conn;
            }

            set
            {
                connectionString = value;
            }
        }

        public BDConexaoBancoDados()
        {
        }

        
        public DataTable LeDados<T>(string query) where T : IDbConnection, new()
        {
            using (var conn = new T())
            {
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = query;
                    cmd.Connection.ConnectionString = ConnectionString;
                    cmd.Connection.Open();
                    var table = new DataTable();
                    table.Load(cmd.ExecuteReader());
                    return table;
                }
            }
        }


        public DataTable LeDadosAdapter<S, T>(string query) where S : IDbConnection, new()
                                                            where T : IDbDataAdapter, IDisposable, new()
        {
            using (var conn = new S())
            {
                using (var da = new T())
                {
                    using (da.SelectCommand = conn.CreateCommand())
                    {
                        da.SelectCommand.CommandText = query;
                        da.SelectCommand.Connection.ConnectionString = ConnectionString;
                        DataSet ds = new DataSet();
                        da.Fill(ds);
                        return ds.Tables[0];
                    }
                }
            }
        }

        public int ExecuteQuery<S>(string query) where S : IDbConnection, IDisposable, new()
        {
            using (var conn = new S())
            {
                conn.ConnectionString = ConnectionString;
                conn.Open();
                using (var da = conn.CreateCommand())
                {
                    da.CommandText = query;
                    int retorno = da.ExecuteNonQuery();
                    conn.Close();
                    return retorno;
                }
            }
        }

        public void ExecuteProcedureOracle<S>(string procedureName, List<OracleParameter> param) where S: IDbConnection, IDisposable, new()
        {
            if (procedureName != string.Empty)
            {
                using (var conn = new S())
                {
                    conn.ConnectionString = ConnectionString;
                    conn.Open();
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = procedureName;
                        cmd.CommandType = CommandType.StoredProcedure;
                        foreach(OracleParameter p in param)
                        {
                            cmd.Parameters.Add(p);
                        }
                        int ret = cmd.ExecuteNonQuery();
                    }

                    conn.Close();
                }
            }
        }
    }
}
