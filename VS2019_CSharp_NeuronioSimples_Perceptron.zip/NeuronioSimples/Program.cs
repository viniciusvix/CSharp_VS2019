﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuronioSimples
{
    class Program
    {
        /*static void Main(string[] args)
        {
            Console.WriteLine("Insira a entrada A:");
            int A = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Insira a entrada B:");
            int B = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Insira o valor de bias:");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Resultado é :" + Cerebro.Neuronio(A, B, b));
            Console.Read();
        }
        */


        #region Procedimento para teste do Perceptron
        
        public static void Main(string[] args)
        {
            int iOut = 1;

            Perceptron perceptron = new Perceptron();

            while (iOut != 0)
            {
                perceptron.EpocasMax = iOut;
                ExecutePerceptron(perceptron);
                iOut = Convert.ToInt32(Console.ReadKey().KeyChar.ToString());
            }

            
        }

        public static void ExecutePerceptron(Perceptron perceptron)
        {
            //pesos antes do treinamento
            perceptron.Pesos.ToList().ForEach(x => Console.WriteLine(x + ","));

            Console.WriteLine("\n");

            //efetua-se o treinamento da rede
            perceptron.Treinar();

            Console.WriteLine("\n");

            //pesos ajustados após treinamento
            perceptron.Pesos.ToList().ForEach(x => Console.WriteLine(x + ","));

            //dados de entrada para rede treinada, 0 e 0 resulta em 0 (tabela and) -1 corresponde ao BIAS

            int[] amostra1 = { 0, 1, -1 }; // 0 e 1 -> 0 Classe B
            int[] amostra2 = { 1, 0, -1 }; // 1 e 0 -> 0 Classe B
            int[] amostra3 = { 0, 0, -1 }; // 0 e 0 -> 0 Classe B
            int[] amostra4 = { 1, 1, -1 }; // 1 e 1 -> 1 Classe A


            ClassificarAmostra(amostra1, perceptron.Pesos);
            ClassificarAmostra(amostra2, perceptron.Pesos);
            ClassificarAmostra(amostra3, perceptron.Pesos);
            ClassificarAmostra(amostra4, perceptron.Pesos);
        }

        public static void ClassificarAmostra(int[] amostra, double[] w)
        {
            //pesos encontrados após o treinamento
            double[] pesos = w;

            //aplicação da separação dos dados linearmente após aprendizado
            var u = amostra.Select((t, k) => pesos[k] * t).Sum();

            var y = LimiarAtivacao(u);

            Console.WriteLine(y > 0 ? "Classe A - " + DateTime.Now.Millisecond : "Classe B - " + DateTime.Now.Millisecond);
        }

        private static int LimiarAtivacao(double u)
        {
            return (u >= 0) ? 1 : 0;
        }
        #endregion

    }
}
