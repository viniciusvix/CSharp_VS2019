﻿using System;
using System.Linq;

namespace NeuronioSimples
{
    /// <summary>
    /// Classe responsável para o aprendizado e resolução da operador lógico "E"
    /// </summary>
    public class Perceptron
    {
        //pesos sinápticos [0] entrada 1, [1] entrada 2 e [2] BIAS 
        private readonly double[] w = new double[3];
        //vetor da matriz de aprendizado
        private readonly int[,] _matrizAprendizado = new int[4, 3];
        //variável responsável pelo somatório da rede
        private double _net;
        //número de épocas a serem treinadas
        private int epocasMax = 30;
        private double _memory = 0;

        /// <summary>
        /// Atributo para configurar o número de épocas
        /// </summary>
        public int EpocasMax { get => epocasMax; set => epocasMax = value; }
        /// <summary>
        /// Atributo Matriz de Aprendizado
        /// </summary>
        public int[,] MatrizAprendizado { get => _matrizAprendizado; }

        /// <summary>
        /// Atributo Pesos utilizados
        /// </summary>
        public double[] Pesos { get => w; }

        public Perceptron()
        {
            //tabela AND
            _matrizAprendizado[0, 0] = 0; // entrada 1
            _matrizAprendizado[0, 1] = 0; // entrada 2
            _matrizAprendizado[0, 2] = 0; // valor esperado

            _matrizAprendizado[1, 0] = 0; // entrada 1
            _matrizAprendizado[1, 1] = 1; // entrada 2
            _matrizAprendizado[1, 2] = 0; // valor esperado

            _matrizAprendizado[2, 0] = 1; // entrada 1
            _matrizAprendizado[2, 1] = 0; // entrada 2
            _matrizAprendizado[2, 2] = 0; // valor esperado

            _matrizAprendizado[3, 0] = 1; // entrada 1
            _matrizAprendizado[3, 1] = 1; // entrada 2
            _matrizAprendizado[3, 2] = 1; // valor esperado

            w[0] = 0; // peso sináptico para entrada 1
            w[1] = 0; // peso sináptico para entrada 2
            w[2] = 0; // peso sináptico para BIAS

        }

        /// <summary>
        /// Método responsável pela função principal do perceptron que é o somatório das entradas/pesos
        /// e pela função de ativação do perceptron.
        /// </summary>
        /// <param name="x1">entrada 1</param>
        /// <param name="x2">entrada 2</param>
        /// <returns></returns>
        int Executar(int x1, int x2)
        {
            int ret;

            ///Se existir memória do resultado anterior, ao ser realizado o treino, 
            ///a memória será utilizada como a soma do resultado anterior lembrado com
            ///o resultado obtido recente. Com isso, espera-se simular a "lembrança" aprendida
            ///e com isso somar com o que tem-se hoje.
            if(_memory != 0)
                //_net = (x1 * w[0]) + (x2 * w[1]) + ((-1) * w[2]) + ((x1 * _memory) + (x2 * _memory) + ((-1) * _memory));
                _net = (x1 * _memory) + (x2 * _memory) + ((-1) * _memory);
            else
                _net = (x1 * w[0]) + (x2 * w[1]) + ((-1) * w[2]);

            if (_net >= 0)
                ret = 1;
            else
            {
                ///Apenas armazena o resultado anterior se não houver ativação. Com isso pretendemos
                ///simular a fixação da lembrança no perceptron. Assim como a "lembrança", ou parte dela,
                ///é fixada na própria célula neural.
                _memory = _net;
                ret = 0;
            }

            return ret;
        }

        /// <summary>
        /// Método de treinamento do perceptron
        /// </summary>
        public void Treinar()
        {
            var treinou = true;
            int countEpocas = 0;

            ///Percorre as entradas configuradas executando a função do perceptron.
            ///Neste caso, os valores configurados na matriz de aprendizado.
            for (var i = 0; i < MatrizAprendizado.GetLength(0); i++)
            {
                ///Variável que armazena o resultado do perceptron, ou seja, se o perceptron
                ///foi ativado ou não
                var saida = Executar(MatrizAprendizado[i, 0], MatrizAprendizado[i, 1]);

                //Verifica se a função do perceptron retornou diferente do valor esperado
                if (saida != MatrizAprendizado[i, 2])
                {
                    //Se for diferente, os pesos serão corrigidos
                    CorrigirPeso(i, saida);
                    //e o treinamento será realizado novamente considerando novos pesos
                    treinou = false;
                }
            }

            countEpocas++;

            ///Se o resultado do treinamento for diferente do esperado e ainda o número de
            ///épocas para treinamento ainda não foi atingido, será feito o treinamento 
            ///novamente do perceptron.
            if (!treinou && (countEpocas < EpocasMax))
                Treinar();
        }

        /// <summary>
        /// Método responsável em realizar o ajuste nos pesos.
        /// </summary>
        /// <param name="i">indice da matriz de aprendizado</param>
        /// <param name="saida">valor da variável de saida do perceptron</param>
        void CorrigirPeso(int i, int saida)
        {
            w[0] = w[0] + (1 * (MatrizAprendizado[i, 2] - saida) * MatrizAprendizado[i, 0]);
            w[1] = w[1] + (1 * (MatrizAprendizado[i, 2] - saida) * MatrizAprendizado[i, 1]);
            w[2] = w[2] + (1 * (MatrizAprendizado[i, 2] - saida) * (-1));
        }
    }
}
