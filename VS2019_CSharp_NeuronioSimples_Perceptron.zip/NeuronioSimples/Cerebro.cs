﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuronioSimples
{
    public class Cerebro
    {
        public static int Neuronio(int A, int B, int bias)
        {
            int resultado = 0;
            int f = B + A + bias;

            if (f > 0)
                resultado = 1;
            else if (f <= 0)
                resultado = 0;

            return resultado;
        }
    }
}
